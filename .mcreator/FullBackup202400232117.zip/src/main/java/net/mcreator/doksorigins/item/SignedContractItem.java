
package net.mcreator.doksorigins.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SignedContractItem extends Item {
	public SignedContractItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
