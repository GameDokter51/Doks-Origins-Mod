package net.mcreator.doksorigins.procedures;

import net.minecraft.world.item.ItemStack;

import net.mcreator.doksorigins.init.DoksOriginsModItems;

public class SignedContractTooltipProcedure {
	public static void execute(ItemStack itemstack) {
		if (itemstack.getItem() == DoksOriginsModItems.SIGNED_CONTRACT.get()) {
		}
	}
}
