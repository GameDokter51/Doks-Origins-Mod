
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.doksorigins.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.doksorigins.item.SignedContractItem;
import net.mcreator.doksorigins.item.ContractItem;
import net.mcreator.doksorigins.DoksOriginsMod;

public class DoksOriginsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, DoksOriginsMod.MODID);
	public static final RegistryObject<Item> CONTRACT = REGISTRY.register("contract", () -> new ContractItem());
	public static final RegistryObject<Item> SIGNED_CONTRACT = REGISTRY.register("signed_contract", () -> new SignedContractItem());
	// Start of user code block custom items
	// End of user code block custom items
}
